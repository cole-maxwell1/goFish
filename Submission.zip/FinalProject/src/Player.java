import java.util.ArrayList;

/**
 * An abstract class that has the properties of a Go Fish player
 */
public abstract class Player
{
    public String name; // This string stores the player's name.
    public ArrayList<Card> hand = new ArrayList<>(); // Meanwhile, this array list stores the player's cards.
    private int numBooks; // This integer field keeps track of the player's score, based on the number of their books.

    public Player()
    { // Initially, the player will fish for 7 cards to create their hand.
        for(int i=0; i < 8; i++)
            fish();
    } // end constructor

    /**
     * Gets the name of a player.
     * @return A string containing the player's name.
     */
    public String getName()
    {
        return name; // The name field is returned.
    }

    /**
     * Sets the name of a player.
     * @param playerName A string to set the player name to.
     */
    public void setName(String playerName)
    {
        name = playerName; // The name field is set to a specified string.
    }

    /**
     * Checks if a card has been given to another player
     * @param cardType a card value (ace, one, jack, king, etc...)
     * @return True is the players hand contains the
     * cardType, otherwise false
     */

    public boolean hasCard(Card cardType)
    { // If the hand contains a specific type of card, true will be returned. Otherwise, false will be returned.
        return hand.contains(cardType);
    }// End hasCard

    /**
     * Returns an array of cards to give to another player given a card type to look for
     * @param cardType A card value
     * @return An array of the cards that are being given
     */
    public ArrayList<Card> giveCard(Card cardType)
    {
        ArrayList<Card> givenCardArray = new ArrayList<>();
        // ^A new array list is created for returning one or more cards.
        for (int i = 0; i < hand.size(); i++) // This for loop is used to add cards from
            if (hand.get(i) == cardType)      // a player's hand to the givenArray.
                givenCardArray.add(hand.get(i)); // The card can only be added if it
                                                 // matches the card requested.
        for (int c = 0; c < givenCardArray.size(); c++) // This for loop takes all cards within
            hand.remove(cardType);  // the given array and removes them from the player's hand.
        return givenCardArray; // At the end, the given array is returned.
    }// End giveCard

    /**
     * Asks the next player for a given card type
     * @param cardType a card value
     * @return a boolean representing if the next player has the card type asked for
     */
    public boolean askFor(Card cardType, Player target)
    {
        boolean result = false; // A result is initialized as false. If the asking player does not
                                // receive cards from the other player, this will be returned as is.
        if (target.hasCard(cardType))
        {   // If the other player has a card or cards of a given type, the asking player will be given
            for(Card c: target.giveCard(cardType)) // the cards for as long as the other player has them.
                hand.add(c);
            result = true; // In this case, true is returned, as the player did receive cards.
        } // End if
        return result; // The result is returned at the very end.
    } // End askFor

    /**
     * Allows a player to fish for a card if needed, and then adds the card to the player's hand.
     * @return A card, which is either the card taken from the deck or null if the deck is empty.
     */
    public Card fish()
    {
        Card goFish = null; // A card is initialized as null. It will be returned if the deck is empty.
        if (GoFish.deckSize() > 0)
        { // If the deck size is greater than zero, the following will occur:
            goFish = GoFish.draw(); // The goFish card is set to the card drawn from the deck.
            hand.add(goFish); // The card is then added to the player's hand.
        } // End if
        else
        { // If the deck is at 0, then it is clearly empty. The player will be notified as follows:
            System.out.println("The deck is empty!"); // A statement will be printed out to the console.
        } // End else
        return goFish; // The card, regardless of its value, will be returned at the very end.
    } // End fish

    /**
     * Gets the number of books that a player has won.
     * Acts as the score keeping mechanism for a player.
     * @return The score of the player in "books"
     */
    public int getNumBooks()
    {
        return numBooks; // The number of books, which is the same as the player's score, is returned.
    } // end getNumBooks

    /**
     * Checks to see if the player's hand contains a book of four cards.
     * @return The book of cards that was generated, or null, indicating that a book was not created.
     */
    public Card checkForBooks()
    {
        Card subject = null;
        for(Card c: hand) // For as long as there are cards in the player's hand, this loop will run.
        {
            int num = 0; // A variable is set aside for counting up the number of cards in the player's hand.
            for(Card d: hand) // For as long as there are other cards in the player's hand, comparisons will be made
                if (c == d)   // to determine if the variable can be increased in value.
                    num++;
            if (num == 4)
            {   // If the variable matches four, then a for loop will run. For as long as there are cards
                for(int i=0;i<4;i++) // left to take into account,
                    hand.remove(c); // each card taken into account will be removed from the hand,
                numBooks++;         // and the number of books will be increased.
                subject = c;
            } // End if
        } // End for
        return subject;
    } // end checkForBooks

    /**
     * A placeholder method that will serve as a means of
     * instituting any type of player's turn in a game
     * of Go Fish.
     * @param turn The turn number
     */
    public abstract void haveTurn(int turn);

} // End Player